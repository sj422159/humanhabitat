

<!DOCTYPE html>
<html lang="en">
<head> 
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
   <link rel="stylesheet" href="../style.css"> 
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Belanosima&display=swap" rel="stylesheet">
    <title>consumer</title>
  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
 * {
    margin: 0;
    padding: 0;

    box-sizing: border-box;
}
 body{
    
  background: url("https://images.unsplash.com/photo-1593115057322-e94b77572f20?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1171&q=80");
    background-size: cover;
    background-repeat: no-repeat;
    height: 100%;  
 }
.container{
    
    display: flex;
    padding: 58px;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
 }
 .name{
    display:flex;
    flex-direction:column;
    width:450px;
    color:white;
 }
 .name h1{
    text-align:center;
 }
.name h4{
    padding-left: 45px;
    color:white;
     text-align: left;
     font-size: 80px;
    font-family: sans-serif;
}
 .name ul{
    color: white;
    padding-left: 55px;
    font-size: 25px;
    display: flex;
    flex-direction: column;
    gap: 26px;
}
.name ul li{
    color:white;
}
.cardd {
    background-color: white;
    color: black;
    width: 489px;
    padding: 47px;
    padding-top: 5px;
  
    margin: 2px;
    border-radius: 12px;
    box-shadow: 10px 10px 15px rgb(9, 9, 10);
}

.title {
    display: flex;
    padding: 2px;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-around;
}

.cardd img{
    position: relative;
     height: 60px;
     width: 60px;
     border-radius: 50%;
     overflow: hidden;
}
.cardd h4{
    text-align:center ;
    font-size: 25px;
    padding-Right: 30px;
}
.cardd form{
    font-family: sans-serif;
}
button {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
    }
    button:hover {
        background-color: #45a049;
    }
    .cancelbtn {
        width: auto;
        padding: 10px 18px;
        background-color: #f44336;
}
 section{
    display: flex;
    align-items: center;
    justify-content: right;
}
.large {
    font-size: 1.0in;
    color:red;
    font-weight: 700;
    animation-name: welcome;
    animation-duration: 4s;
    animation-iteration-count: 1;
}
.query {
    color: black;
    margin-top: 65px;
    display: flex;
    justify-content: space-around;
    align-items: center;
}
.query button {
    color: #e60d0d;
    background: #08c94c;
    font-size: 0.2in;
    width: 2in;
    margin: 15px;
    padding: 15px;
    border: 3px solid rgb(233 9 9);
    border-radius: 10px;
    transition: all ease 1s;
}
</style>
</head>

<body >

    
      
         <!-- navbar starts -->
       
   <?php
   require '../partials/nav.php';
   ?>

<div class="container">

<!-- <div class="name"><h1>Consumer Protection Consultation</h1>
<ul>
<li>Lawyers with domain expertise are available for your consultation.</li>
<li>Get personalized advice and find solutions tailored to your specific needs.</li>
<li>Book a 1-hour session with an expert lawyer to discuss your unique legal concerns.</li>
</ul>  </div>  -->
<section>
<div class="cardd">
    <div class="title">
       
<div class="h4">
    <h4>Lok Adalat</h4>
</div>
    </div>
    <div class="forms">
<form name="dropForm">
  
  <p>Choose your method:</p>
  <select name="dropSelect" onchange="showDropInfo()">
    <option value="P">Select:</option>
    <option value="A">Arbitration</option>
    <option value="M">Mediation</option>
    <option value="C">Conciliation</option>
  </select>

  <p id="pF"></p>

  <p>Choose your mode:</p>
  <input type="radio" id="html" name="mode" value="self" required="true/">
  <label for="html">Self</label><br>
  <input type="radio" id="through attorney" name="mode" value="through attorney">
  <label for="through attorney">Through Attorney</label><br>

  <p>Choose your status:</p>
  <input type="radio" id="ind" name="status" value="Individual" onclick="window.location.href = '../small claim bench/ind.php'">
  <label for="ind">Individual</label><br>
  <input type="radio" id="org" name="status" value="organisation" onclick="window.location.href = '../small claim bench/org.php';">
  <label for="org">Organisation</label><br>
</form>
</div>
</div>

      
  </div>  
</div>
</section>

<script>
  function showDropInfo() {
    var sT = dropForm.dropSelect;
    var pF = document.getElementById("pF");
    if(sT.selectedIndex==1)
    {
    pF.innerHTML =
      '<input type="radio" id="arb" name="method" value="arb"> <label for="arb">Arbitration</label><br><input type="radio" id="med" name="method" value="med"><label for="med">MedArb</label><br><input type="radio" id="con" name="method" value="con"><label for="con">ConcilArb</label><br><input type="radio" id="ama" name="method" value="ama"> <label for="ama">ArbMedArb</label><br><input type="radio" id="caa" name="method" value="caa"> <label for="caa">Court Annexed Arbitration</label><br>';
    }

    else if(sT.selectedIndex==2)
    {
    pF.innerHTML =
      '<input type="radio" id="cbm" name="method" value="cbm"> <label for="cbm">Consent Based Mediation</label><br><input type="radio" id="mm" name="method" value="mm"><label for="mm">Mandatory Mediation</label><br><input type="radio" id="ma" name="method" value="ma"><label for="ma">MedArb</label><br><input type="radio" id="crm" name="method" value="crm"> <label for="crm">Consent Referred Mediation</label>';
    }
    else{
      pF.innerHTML =
      '<input type="radio" id="vc" name="method" value="vc"> <label for="vc">Voluntary Conciliation</label><br><input type="radio" id="cc" name="method" value="cc"><label for="cc">Cmpulsory Consiliation</label><br><input type="radio" id="cr" name="method" value="cr"><label for="cr">Court Referred</label>';

    }
    }
  </script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>

<script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>    

