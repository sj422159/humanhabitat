<?php
require '../partials/nav.php';
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
<link rel="stylesheet" href="../style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link href="https://fonts.googleapis.com/css2?family=Belanosima&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<style>
  .loader-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5); /* Add a semi-transparent overlay */
  display: flex;
  justify-content: center;
  align-items: center;
}

.loader {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #3498db;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
  
a {
    color: white;
    text-decoration: none;
}

.imageone{
  font-family: 'Times New Roman', Times, serif;
    font-size: larger;
    display: flex;
    width: 100vw;
    align-items: center;
    justify-content: space-around;

}

.imageone  h1{
  background-image: linear-gradient(45deg, #553c9a, #b393d3);
  color: transparent;
  background-clip: text;
  font-size: xx-large;
  -webkit-background-clip: text;
}
body{
    background:white;
}
.loader-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5); /* Add a semi-transparent overlay */
  display: flex;
  justify-content: center;
  align-items: center;
}

.loader {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #3498db;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}


button{
    font-size: large;
    padding: 1%;
}

.join{
background-image: radial-gradient(  #cc3517,#183699);
color: transparent;
background-clip: text;
-webkit-background-clip: text;
margin-top: 0;
font-size: 3em;
}
#btn1{
    background-color: #087f79;
    transition: 0.2s;
    border-radius: 0;
    padding: 1.5%;
    text-decoration: none;
    color: white;
    border:groove black;
    
}
#btn1:hover {
    background-color: #e04f23;
    transition: 0.2s;
    border-top-left-radius: 1rem;
    border-bottom-right-radius: 1rem;
}
    
#callback{
  background-color: #087f79;
  transition: 0.2s;
  border-radius: 0;
  padding: 1.5%;
  text-decoration: none;
  color: white;
  border:groove black;
 
    
}
#callback:hover{
  background-color: rgb(157, 223, 157); 
    transition: 0.2s;
    border-top-left-radius: 1rem;
    border-bottom-right-radius: 1rem;
}
.get{
    
    width:full-width;
    padding: 5%;
    margin-top: 5vh;
}
.getimages{
  display: flex;
    gap: 10px;

    
}
.second{
    display: inline-flex;
    margin-top: 8%;
}
.get h1{
  font-size: 3em;
    text-align: center;
    color: rgb(102, 102, 101);
    
}
.get h2{
    color: mediumblue;
}
.footerone{
  display: flex;
    flex-wrap: wrap;
    width: 100%;
    justify-content: space-around;
    align-items: center;
    
    box-sizing: border-box;
}
    
   
 
  .footer{
    height: 180px;
   padding: 2%;
   display: flex;
    flex-wrap: wrap;
    width: 100%;
    justify-content: space-around;
    align-items: center;
   
    box-sizing: border-box;
    background-color: #c1c1ba;
  }
  .footer h1{
    font-size: 3em;
  }
 .search{
  font-size: 1em;
  width: 18vw;
  padding: 3%;
  background-color: rgb(236, 232, 232);
 }

 .card:hover{
  background-color:rgb(9, 226, 255)
 }
 .txt{
  text-align:center;
  word-wrap:break-word;
  display:flex;
  font-size: x-large;
  flex-direction:column;
  align-items:center;
  width: 700px;
 }
 .serv{
  list-style-type: none;
 }

.more-content {
  display: none;
}

.read-more {
  display: inline-block;
  color: blue;
  cursor: pointer;
}
.card{
  background-color:#dadbdb;
  border:1px solid black;
 }
 .card:hover{
    background-color:azure;
 }

.card-body {
    flex: 1 1 auto;
       color: var(--bs-card-color);
    text-align: center;
}
 .nav-link {
    color: black;
    font-size: x-large;
    font-family: 'Belanosima', sans-serif;;
}
.joinus{
    background-color:rgb(250, 250, 233);   
    padding: 6%;
}
.footer button{
    margin-left: 36rem;
    width: 20%;
    height: 5%;
    color: white;
    background-color: darkgreen;
  }
</style>
</head>
<body>
 
<div id="loader" class="loader-overlay">
  <div class="loader"></div>
</div>
<div class="gif">
    <div class="imageone">
        
        <div class="txt"><h1> The Digital Online Dispute Resolution (ODR)Centre</h1>
        <!-- <h5>   A Digital Solution for ADR Centre</h5> -->
        <p>
          <br>
           ODR is the resolution of disputes, particularly small- and medium-value cases,  <span class="more-content"> using digital technology and techniques of ADR, such as arbitration, conciliation and mediation.</span></p> <a href="#" class="read-more">Read more</a> 
         <p>  Settle your disputes out of the courts in the comforts of your homes with our smart ODR platform.</p>
         <p>  It reduces the dependence of disputants on lawyers while integrating with your existing dispute resolution ecosystem.</p></div>
        <div class="image"><img src="odr-platform.gif" width="500" height="400" > </div>
      </div></div></div>
      <br><br>
      <div class="joinus">
      <h1 class="join"><center>JOIN US NOW</center></h1><br>
      <div class="buttons"><center><a href="odr_bookconsultation.php" type="button" id="btn1" class="shadow p-3 mb-5 bg-body-primary rounded">BOOK A CONSULTATION</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="callback.php" type="button" class="shadow p-3 mb-5 bg-body-primary rounded" id="callback"  >REQUEST A CALLBACK</a></center></div><br><br><br>
    </div>
    <div class="get">
        <h1>WHAT YOU WILL GET?</h1><br><br>
<div class="getimages">
      <div class="card" style="width: 20rem;height:20rem" >
        <img src="availability .png" class="card-img-top" alt="...">
      <div class="card-body">
        <h4 class="card-text"> Availability 24*7</h4>
        </div></div> 
      <div class="card" style="width: 20rem;height:20rem">
        <img src="decisions.png" class="card-img-top" ><div class="card-body">
        <h4 class="card-text"> Quick Decisions From Expert Lawyers</h4>
        </div>
      </div> 
      <div class="card" style="width: 20rem;height:20rem" >
        <img src="price.png" class="card-img-top" alt="..." ><div class="card-body">
        <h4 class="card-text"> Standard Price</h4>
        </div>
      </div>
    
      <div class="card" style="width: 20rem;height:20rem">
        <img src="video.png" class="card-img-top" alt="..."><div class="card-body">
        <h4 class="card-text"> Videoconferencing</h4>
        </div>
      </div> 
      <div class="card" style="width: 20rem;height:20rem" >
        <img src="support.png" class="card-img-top" ><div class="card-body">
        <h4 class="card-text"> Dedicated Support</h4>
        </div>
      </div> </div>    
      </div>
    <div class="footer">
        <div class="footerone">
        <h1>Do You Have Any Query?</h1> <button url="../hm,abt,con\contactus.php" class="lastbutton">CONTACT US &#x2192</button></div>
        </div>
        <script>
        document.addEventListener("DOMContentLoaded", function () {
  const readMoreLinks = document.querySelectorAll(".read-more");

  readMoreLinks.forEach(function (link) {
    link.addEventListener("click", function (event) {
      event.preventDefault();
      const content = this.previousElementSibling.querySelector(".more-content");
      if (content.style.display === "none" || content.style.display === "") {
        content.style.display = "inline";
        this.textContent = "Read less";
      } else {
        content.style.display = "none";
        this.textContent = "Read more";
      }
    });
  });
});

        </script>
        
          <script>
    // Show the loader initially
document.addEventListener("DOMContentLoaded", function() {
  document.querySelector(".loader-overlay").style.display = "flex";
});

// Hide the loader 4 seconds after the page is fully loaded
window.addEventListener("load", function() {
  setTimeout(function() {
    document.querySelector(".loader-overlay").style.display = "none";
  }, 4000); // 4000 milliseconds = 4 seconds
});

</script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
       
</body>
</html>