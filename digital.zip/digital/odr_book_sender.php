<?php
include("db1_conn.php");

if(isset($_POST['submit']))
{
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['mobile'];  // Corrected variable name from $mobile to $phone
  $Date = $_POST['Date'];
  $mode = $_POST['fav_language'];

  $query = "INSERT INTO odr_book_consultation VALUES ('$name', '$email', '$phone', '$Date', '$mode')";
  $data = mysqli_query($conn, $query);

  if ($data) {
    header("Location: pay.html");
  
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>