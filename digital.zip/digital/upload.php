<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cards</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>body {
        width: 100%;
        background-image:url("paybg.jpg");
        background-color:black;
        background-size: cover;
        color: black;
        display: flex;
        justify-content: center; /* To center the content horizontally */
        height: 100vh; /* Set the height to occupy the full viewport */
        margin: 0; /* Remove default body margin */
    }
    
    .card-container {
        position: relative;
        display: flex;
        flex-direction: row;
        align-items: center; /* Center cards horizontally */
        gap: 20px;
    }
    
    .card {
        background-color: white;
        flex-direction: column; /* Arrange cards vertically */
        padding-top: 20px;
        padding-left: 20px;
        justify-content: space-around;
        width: 450px;
        height: 400px;
        border-radius: 12px;
        box-shadow: 10px 10px 15px rgb(9, 9, 10);
        margin-bottom: 20px; /* Add spacing between the boxes */
    }
    
    .card img {
        position: relative;
        left: 50px;
        width: 250px;
        height: 250px;
        
    }

    .card .steps img {
        position: relative;
         height: 40px;
         width: 40px;
         border-radius: 50%;
         overflow: hidden;
    }         
    
    .card h4 {
        text-align: center;
        font-family: sans-serif;
        font-size: larger;
        text-decoration: underline; /* Use text-decoration instead of <u> tag */
            
    }
    
    .card p {
        text-align: center; /* Center the text */
    }
    .button {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin-top:10px;
        margin-left:80px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 40%;
        text-align:center;
    }
    .button:hover {
        background-color: #45a049;
    }
    
    .card button input{
   height: 100%;
   width: 100%;
   border-radius: 5px;
   border: none;
   color: #fff;
   font-size: 18px;
   font-weight: 500;
   letter-spacing: 1px;
   cursor: pointer;
   transition: all 0.3s ease;
   background: linear-gradient(135deg, #1e1e1e,#71ba12);
   }
   .card button input:hover{
  /* transform: scale(0.99); */
  background: linear-gradient(-135deg, #1e1e1e,#ff7200);
  }
    </style>

</head>
<body >
        
    <div class="card-container">
        <div class="card">
            <h4>Payment Details</h4><br>
            <form class = ""action="" method = "post" autocomplete="off" enctype="multipart/form-data">
                <label for="name">Enter your Name:</label>
                <input type="text" id="name" name="name" required><br><br>
               
                <label for="mobile">Enter your Mobile No.:</label>
                <input type="mobile" id="mobile" name="mobile" required><br><br>
                
                <label for="number">Enter your Transaction ID:</label>
                <input type="number" id="number" name="number" required><br><br>
       
                <label for="upload">Upload Payment Screenshot:</label>
                <input type="file" id="upload" name="upload" accept = ".jpg, .jpeg, .png" value ="" required><br><br> 

                <label for="des">payment description:</label>
                <textarea id="des" name="textarea" rows="4" cols="50"placeholder="Enter the description of payment..." required> </textarea>
                <input type="submit" value="Submit" class="button" name="submit">
                                   
        </div>     
    </div>
</body>
</html>




<?php
include("db1_conn.php");

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $tid = $_POST['number'];
    $des = $_POST['textarea'];

    // Process uploaded file
    $upload_destination = ""; // Initialize an empty value for now
    if ($_FILES['upload']['error'] === UPLOAD_ERR_OK) {
        $upload_tmp = $_FILES['upload']['tmp_name'];
        $upload_name = $_FILES['upload']['name'];
        // Assuming you want to store the uploaded file in the "uploads" folder
        $upload_destination = "uploads/" . $upload_name;
        move_uploaded_file($upload_tmp, $upload_destination);
    }

    // Assuming your table columns are named accordingly
    $query = "INSERT INTO payment (_name, mobile, transaction_id, payment_screenshot,_des) VALUES (?, ?, ?, ?,?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sssss", $name, $mobile, $tid, $upload_destination,$des);

    if (mysqli_stmt_execute($stmt)) {
        echo '<script>alert("Data inserted successfully")</script>';
    } else {
        echo '<script>alert("enter correct details")</script>';
    }

    mysqli_stmt_close($stmt);
}
?>