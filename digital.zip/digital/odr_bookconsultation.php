<?php
include("db_connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head> 
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
   <link rel="stylesheet" href="../style.css"> 
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Belanosima&display=swap" rel="stylesheet">
    <title>Book Consultation</title>
  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
 * {
    margin: 0;
    padding: 0;

    box-sizing: border-box;
}
 body{
    
    background-image: url("pay.jpg");
    background-size: cover;
    background-repeat: no-repeat;
    height: 100%;  
 }
.container{
    
    display: flex;
    padding: 58px;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
 }
 .name{
    display:flex;
    flex-direction:column;
    width:450px;
    color:white;
 }
 .name h1{
    text-align:center;
 }
.name h4{
    padding-left: 45px;
    color:white;
     text-align: left;
     font-size: 80px;
    font-family: sans-serif;
}
 .name ul{
    color: white;
    padding-left: 55px;
    font-size: 25px;
    display: flex;
    flex-direction: column;
    gap: 26px;
}
.name ul li{
    color:white;
}
.cardd {
    background-color: white;
    color: black;
    width: 489px;
    padding: 47px;
    padding-top: 5px;
  
    margin: 2px;
    border-radius: 12px;
    box-shadow: 10px 10px 15px rgb(9, 9, 10);
}

.title {
    display: flex;
    padding: 2px;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-around;
}

.cardd img{
    position: relative;
     height: 60px;
     width: 60px;
     border-radius: 50%;
     overflow: hidden;
}
.cardd h4{
    text-align:center ;
    font-size: 25px;
    padding-Right: 30px;
}
.cardd form{
    font-family: sans-serif;
}
.button {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
    }
    .button:hover {
        background-color: #45a049;
    }
    .cancelbtn {
        width: auto;
        padding: 10px 18px;
        background-color: #f44336;
}
 section{
    display: flex;
    align-items: center;
    justify-content: right;
}
.card button {
        position: relative;
        left: 80px;
        height: 40px;
        margin: 35px;
        align-items:center;
        margin-top: auto; /* Push the button to the bottom */
        background-color: rgb(54, 210, 54);
    }
    
    .card button input{
   height: 100%;
   width: 100%;
   border-radius: 5px;
   border: none;
   color: #fff;
   font-size: 18px;
   font-weight: 500;
   letter-spacing: 1px;
   cursor: pointer;
   transition: all 0.3s ease;
   background: linear-gradient(135deg, #1e1e1e,#71ba12);
   }
   .card button input:hover{
  /* transform: scale(0.99); */
  background: linear-gradient(-135deg, #1e1e1e,#ff7200);
  }
</style>
</head>

<body >

    
      
         <!-- navbar starts -->
       
   <?php
   require '../partials/nav.php';
   ?>

<div class="container">

<div class="name"><h1>Book Consultation</h1>
<ul>
<li>Lawyers with domain expertise are available for your consultation.</li>
<li>Get personalized advice and find solutions tailored to your specific needs.</li>
<li>Book a 1-hour session with an expert lawyer to discuss your unique legal concerns.</li>
</ul>  </div> 
<section>
<div class="cardd">
    <div class="title">
        <div class="img">
    <img src="client.png" width="100px" height="100px">
</div>
<div class="h4">
    <h4>Book Consultation</h4>
</div>
    </div>
    <form action="odr_book_sender.php" method = "POST">
        <label for="name">Enter your Name:</label>
        <input type="text" id="name" name="name" required><br><br>
       
        <label for="email">Enter your email:</label>
        <input type="email" id="email" name="email" required><br><br>
        
        <label for="mobile">Enter your Mobile No.:</label>
        <input type="tel" id="mobile" name="mobile" required><br><br>

        <label for="Date">Date Of Consultation:</label>
        <input type="Date" id="Date" name="Date" required><br><br>    

        <p>Select Mode Of Conversation</p>
        <input type="radio" id="InPerson" name="fav_language" value="In Person" required>
        <label for="Inperson">In Person</label>
        <input type="radio" id="Skype" name="fav_language" value="Skype" required>
        <label for="Skype">Skype</label>
        <input type="radio" id="Phone Call" name="fav_language" value="Phone Call" required>
        <label for="PhoneCall">Phone Call</label><br><br>
      <p>Starting from ₹1,500*</p>
      
      <input type="submit" value="Pay Now" class="button" name="submit">
 

      </div>
      
  </div>  
</div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>

<script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>    


