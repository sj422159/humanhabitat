-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2023 at 08:51 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digital`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_consultation`
--

CREATE TABLE `book_consultation` (
  `name` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` int(20) NOT NULL,
  `Date` date NOT NULL,
  `mode_of_conversation` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_consultation`
--

INSERT INTO `book_consultation` (`name`, `email`, `mobile`, `Date`, `mode_of_conversation`) VALUES
('SOWMIYA P', 'thanshe4002@gmail.co', 1234567890, '2023-04-21', 'In Person'),
('SOWMIYA P', 'thanshe4002@gmail.co', 1234567890, '2023-04-21', 'In Person'),
('Sowmiya P', 'sivasree1309@gmail.c', 1223344556, '2023-05-11', 'Skype'),
('Sowmiya P', 'sivasree1309@gmail.c', 1223344556, '2023-05-11', 'Skype');

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `name` varchar(50) NOT NULL,
  `mobile` int(20) NOT NULL,
  `number` int(50) NOT NULL,
  `upload` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


ALTER TABLE `payment_details` CHANGE `upload` `upload` BLOB NOT NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
