<html>

<head>
    
<style>

      *{
    margin: 0;
    padding: 0;
    color: black;
    box-sizing: border-box;
}
header{
    width: 100vw;
min-height: 100vh;
 background: white;
background-position: center;
background-size: cover; 
height: 100vh;
font-size: 1.2rem;
display: flex;
justify-content: space-evenly;
align-items: center;
border:2px solid black;
box-sizing:border-box;
box-shadow:5px 5px 2px black;

}

.img{
    display: flex;
    justify-content: center;
    align-items: center;
}
.img img {
height: 496px;
}
.callback img{
    height: 71px;
    width: 279px;
}

a {
    color: #fff9f9;
    text-decoration: none;
}
body{
    width: 100%;
    background-color: black;
    
   
}
body::-webkit-scrollbar {
    display: block;
    width: 8px;
    background: #95c11e;
  }
  body::-webkit-scrollbar-thumb {
    background-color: red;
      border-radius: 50px;
  }
.main{
    width: 100%;
    background: linear-gradient(to top, rgba(0,0,0,0.5)50%,rgba(0,0,0,0.5)50%), url(1.jpg);
    background-position: center;
    background-size: cover;
    height: 100vh;
}

#navbar{
   background-color:white;
   color: white;

} 
#navbar img{
    height: 10vh;
    width: 5vw;
}
.nav-link {
    color: black;
    font-size: x-large;
    font-family: 'Belanosima', sans-serif;;
}
.navbar-nav {
    --bs-nav-link-hover-color:grey;
    
   
}
.navbar{
    --bs-navbar-active-color: grey;
}
.dropdown{
    --bs-navbar-active-color: grey;
    --bs-nav-link-hover-color:grey;
    margin: 2px;
    padding: 12px;
    display: flex;
}
@media (max-width: 1200px)  {
    .dropdown{
    display: block;
 }
 ul.service-list li.animate-charcter {
    display: flex;
    width: 100%;
    justify-content: center;
}
}
body {
            background-color: white;
}

.callback {
            background-color: white;
            width: 30vw;
            margin-top: 20vh;
            box-shadow: 10px 10px 2px black;
            border: solid rgb(20, 104, 17);
        }

        .content {
            padding: 5%;
            font-size: larger;
            font-family: sans-serif;

        }

        .text {
            font-size: 0.8em;
            width: 27vw;
        }

        .para {
            font-size: large;
        }

        #submit {
            width: 27vw;
            padding: 2%;
            border: solid black;
            font-size: large;
            font-family: 'Gill Sans';
        }
    </style>
</head>

<body>

   <header>
    <div class="img">
        <img src="https://cdn.pixabay.com/photo/2015/10/31/11/58/call-center-1015274_1280.jpg" alt="CallUS" srcset="">
    </div>
   
    <div class="callback">
        <div class="img">
    <img src="https://cdn.pixabay.com/photo/2016/12/15/12/26/contact-us-1908763_1280.png" alt=""></div>
        <div class="content">
           
            <form name="callback" method="post" onsubmit="return doValidate();">
                <center>
                    <h3>GET A CALLBACK</h3>
                </center>
                <div class="para">Enter your details to recieve a callback from us..</div><br>Name<br>
                <input type="text" name="name" class="text" placeholder="Enter your name..." require="true"/><br><br>
                Email<br>
                <input type="email" name="email" class="text" placeholder="Enter your email..." /><br><br>
                Contact no.<br>
                <input type="text" name="contact" class="text" placeholder="Enter your phone no..." /><br><br>
                <input type="submit" id="submit" value="Call Me" />
            </form>
        </div>
    </div>
    </header>
    <script>
        function doValidate() {
            if (document.callback.name.value == "") {
                alert("Please put your name");
                document.callback.name.focus();
                return false;
            }
            var readmail = document.callback.email;
            if (readmail.value == "") {
                alert("Please put the correct email address");
                document.callback.email.focus();
                return false;
            }
            if (document.callback.contact.value == "") {
                alert("Please put your phone");
                document.callback.contact.focus();
                return false;
            }
        }
    </script>
</body>

</html>

